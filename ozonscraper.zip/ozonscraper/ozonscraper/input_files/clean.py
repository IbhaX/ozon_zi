import json
import pandas as pd

def excel_to_json(excel_file_path):
    df = pd.read_excel(excel_file_path)
    json_data = df.to_json(orient='records')
    parsed_json = json.loads(json_data)
    return parsed_json, excel_file_path

def load_json():
    with open("updated.json") as f:
        return json.load(f)


def save_excel(data, excel_file_path):
    df = pd.DataFrame(data)
    df.to_excel(excel_file_path, index=False)


def main():
    scraped = load_json()
    input_data, path = excel_to_json("9. Russian Arçelik Stable SKUs - Ozon - Chiara.xlsx")
    
    new_path = f'output/output-{path}'
    new_data = []
    for item in scraped:
        for links in input_data:
            if item["product_link"] == links["product_link"]:
                print(item["product_link"])
                new_data.append(item)
                
    
    save_excel(new_data, new_path)


def update():
    path = "6. Russian Stable Competitors - OZON - Fede (1) 4.xlsx"
    
    with open("update-file-6.json") as f:
        data = json.load(f)
        
    new_output_path = f'output/cleaned-{path}'
    
    for item in data:
        review = item.get("data_content")
        
        author = item.get("data_author")
        
        if author and not review:
            item["url_status"] = "No Reviews"
    
    save_excel(data, new_output_path)
    

update()