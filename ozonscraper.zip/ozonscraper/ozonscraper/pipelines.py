# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import pandas as pd
import logging
from openpyxl import Workbook
from openpyxl.utils.dataframe import dataframe_to_rows


class OzonscraperPipeline:
    def process_item(self, item, spider):
        return item


class ExcelWriterPipeline:
    def __init__(self):
        self.workbook = Workbook()
        self.sheet = self.workbook.active
        self.sheet.title = "Scraped Data"
        self.headers_written = False

    def process_item(self, item, spider):
        if not self.headers_written:
            headers = list(item.keys())
            self.sheet.append(headers)
            self.headers_written = True

        self.sheet.append(list(item.values()))
        return item
    
    def close_spider(self, spider):
        excel_filename = 'scraped_data.xlsx'
        self.workbook.save(excel_filename)
        logging.info(f"Data saved to {excel_filename}")